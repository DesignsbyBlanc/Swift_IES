//
//  WebsitesTableViewController.swift
//  myfavoritewebsites
//
//
//
//

import UIKit

class WebsitesTableViewController: UITableViewController {
    
    var websites:[[String]] = [
        ["Apple",      "https://www.apple.com"],
        ["Wired",      "https://www.wired.com"],
        ["Amazon",   "https://www.amazon.com"],
        ["Sky News", "https://www.skynews.com"],
        ["CNN",        "https://www.cnn.com"]
    ]
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return websites.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cellIdentifier")
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cellIdentifier")
        }
        
        cell!.textLabel!.text = websites[indexPath.row][0]
        cell!.detailTextLabel!.text = websites[indexPath.row][1]
        
        return cell!
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if let url = URL(string: websites[indexPath.row][1])
        {
            UIApplication.shared.open(url)
        }
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // remove the item from the data model
            websites.remove(at: indexPath.row)
            // delete the table view row
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
}
