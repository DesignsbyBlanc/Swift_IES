//
//  ViewController.swift
//  mapview
//
//
//  
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {

    var locationManager = CLLocationManager()
    
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var AreaLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()        
        // Check whether or not location services have been enabled
        // if so, start updating the location
        
        self.locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        let userLocation = locations.last
        let viewRegion = MKCoordinateRegion(center: (userLocation?.coordinate)!, latitudinalMeters: 600, longitudinalMeters: 600)
        
        geocode(latitude: locValue.latitude, longitude: locValue.longitude) { placemark, error in
            guard let placemark = placemark, error == nil else { return }
            DispatchQueue.main.async {
                let address1 = placemark.thoroughfare ?? "-"
                let city = placemark.locality ?? "-"
                let state = placemark.administrativeArea ?? "-"
                let zipcode = placemark.postalCode ?? "-"
                let country = placemark.country ?? "-"
                self.AreaLbl?.text = address1 + ", " + city + ", " + state + ", " + zipcode + ", " + country
            }
        }
        
        self.map.showsUserLocation = true
        self.map.setRegion(viewRegion, animated: true)
        
    }
    
    // Gets latitude, longitude
    func geocode(latitude: Double, longitude: Double, completion: @escaping (CLPlacemark?, Error?) -> ())  {
        // Pass the coordinates to Geocoder
        CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: latitude, longitude: longitude))
        {
            // $0 is the placemarks array, so this returns the first placemark
            // $1 is the error (if applicable)
            completion($0?.first, $1)
        }
    }

}

