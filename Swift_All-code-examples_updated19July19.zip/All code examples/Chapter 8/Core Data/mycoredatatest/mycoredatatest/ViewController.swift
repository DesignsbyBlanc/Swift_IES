//
//  ViewController.swift
//  mycoredatatest
//
//
//
//

import UIKit
import CoreData

class ViewController: UITableViewController {
 
    var items: [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = .white
        navigationController?.navigationBar.barTintColor = UIColor(red: 0/255, green: 122/255, blue: 255/255, alpha:1)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.topItem!.title = "To Do List";
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        //Add in a button and attach action
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add New", style: .plain, target: self, action: #selector(addItem))

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        do {
            items = try managedContext.fetch(fetchRequest)
        } catch let err as NSError {
            print("Failed to fetch items", err)
        }
    
    }
    
    @objc func addItem(_ sender: AnyObject) {
        let alertController = UIAlertController(title: "Add New Task", message: "Please fill in the text fields", preferredStyle: .alert)
        
        alertController.addTextField { (taskitem) in
            taskitem.text = ""
            taskitem.placeholder = "Task Name"
        }
        alertController.addTextField(configurationHandler: { (taskdesc) in
            taskdesc.text = ""
            taskdesc.placeholder = "Description"
        })
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] action in
            let txttask = alertController.textFields![0]
            let txtdesc = alertController.textFields![1]
            let taskstr = txttask.text
            let descstr = txtdesc.text
            
            // Pass values to save method
            self.save(task: taskstr!, description: descstr!)
            self.tableView.reloadData()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func save (task: String, description: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Task", in: managedContext)
        let item = NSManagedObject(entity: entity!, insertInto: managedContext)
        item.setValue(task, forKey: "taskName")
        item.setValue(description, forKey: "taskDesc")
        
        do { // do-catch to try and save the item
            try managedContext.save()
            items.append(item)
        } catch let err as NSError {
            print("Failed to save an item", err)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cellID")
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cellID")
        }
        
        let item = items[indexPath.row]
        //  Add task and description to cell labels
        cell!.textLabel?.text = item.value(forKeyPath: "taskName") as? String
        cell!.detailTextLabel?.text = item.value(forKeyPath: "taskDesc") as? String
        return cell!
    }

}

