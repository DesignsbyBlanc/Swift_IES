//
//  ViewController.swift
//  API Call App
//
//
//
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    var locationManager = CLLocationManager()
    
    var lat: Double = 0.0
    var long: Double = 0.0
    
    let temptype = "metric"
    let stringtemp = "°C"
    
    let APIKey = "YOURAPIKEYGOESHERE"

    @IBOutlet weak var LblTemp: UILabel!
    @IBAction func callAPI(_ sender: Any) {
        //The URL where the data is coming from
        let querytypeURL = "https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(long)&units=\(temptype)&APPID=\(APIKey)"
        
        //Set up a new URL session
        let session = URLSession.shared
        let weatherURL = URL(string: querytypeURL)!
        let dataTask = session.dataTask(with: weatherURL) {
            (data: Data?, response: URLResponse?, error: Error?) in
            if let error = error {
                print("Error:\n\(error)")
            } else {
                //Get the data (if there is any)
                if let data = data {
                    let dataString = String(data: data, encoding: String.Encoding.utf8)
                    print("All the weather data:\n\(dataString!)")
                    //Put JSON object into a dictionary
                    if let jsonObj = ((try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSDictionary) as NSDictionary??) {
                        //Check the dictionary contains a key called "main"
                        if let mainDictionary = jsonObj!.value(forKey: "main") as? NSDictionary {
                            if let temperature = mainDictionary.value(forKey: "temp") { //Get temperature value and add to label
                                DispatchQueue.main.async {
                                    self.LblTemp.text = "Location Temperature: \(temperature) " + self.stringtemp
                                }
                            }
                        } else {
                            print("Error: unable to find temperature in dictionary")
                        }
                    } else {
                        print("Error: unable to convert json data")
                    }
                } else {
                    print("Error: did not receive data")
                }
            }
        }
        dataTask.resume()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        
        //Update lat and long variables
        lat = locValue.latitude
        long = locValue.longitude
        
    }

}

