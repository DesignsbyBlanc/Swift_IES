//
//  ViewController.swift
//  notificationtest
//
//
//
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        UNUserNotificationCenter.current().requestAuthorization(options:
            [[.alert, .sound, .badge]], completionHandler: { (granted, error) in
            print("There was an error requesting authorization")
        })
        
        let button = UIButton(frame: CGRect(x: 100, y: 100, width: 200, height: 50))
        button.backgroundColor = UIColor(red: 0/255, green: 122/255, blue: 255/255, alpha: 1)
        button.setTitle("Get Notification", for: .normal)
        button.addTarget(self, action: #selector(getNotification), for: .touchUpInside)
        button.center = self.view.center
        self.view.addSubview(button)
    }
    
    @objc func getNotification(sender: UIButton!) {
        
        let dateString = "05/05/2019 20:08"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
        let dateFromString = dateFormatter.date(from: dateString)
        
        
        let componentsFromDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: dateFromString!)
        
        let triggerDate = UNCalendarNotificationTrigger(dateMatching: componentsFromDate, repeats: false)
        
        let content = UNMutableNotificationContent()
        content.title = "Swift Reminder"
        content.body = "Don't forget to brush up on your Swift skills."
        content.badge = 1
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        let requestIdentifier = UUID().uuidString
        let request = UNNotificationRequest(identifier: requestIdentifier, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request,
                                               withCompletionHandler: { (error) in
                                                print("There was an error")
        })
    }

}

