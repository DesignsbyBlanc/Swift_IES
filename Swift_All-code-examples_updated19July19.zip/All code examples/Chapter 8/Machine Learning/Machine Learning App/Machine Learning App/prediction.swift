//
//  prediction.swift
//  Machine Learning App
//
//
//
//

import UIKit

class PredictFruit {
    
    let model = ImageClassifier()
    
    enum ClassificationLabel: String {
        case Apple = "Apple"
        case Banana = "Banana"
        case Unknown = "Unknown"
        
        var caseString: String {
            return String(describing: self)
        }
    }
    
    func predictImage(imageToClassify image: UIImage?) -> ClassificationLabel? {
        guard let image = image else {
            print("No image found")
            return nil
        }
        // Convert picture
        guard let pixelBuffer = image.toCVPixelBuffer() else {
            print("Unable to convert image to CVPixelBuffer")
            return nil
        }
        // Try to get a prediction
        guard let prediction = try? model.prediction(image: pixelBuffer) else {
            print("Unable to predict a label for the image")
            return nil
        }
        
        if prediction.classLabel == ClassificationLabel.Apple.caseString {
            return ClassificationLabel.Apple
        } else if prediction.classLabel == ClassificationLabel.Banana.caseString {
            return ClassificationLabel.Banana
        } else {
            return ClassificationLabel.Unknown
        }
        
    }
}
