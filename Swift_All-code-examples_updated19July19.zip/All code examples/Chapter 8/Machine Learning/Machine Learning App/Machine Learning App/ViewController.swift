//
//  ViewController.swift
//  Machine Learning App
//
//
//  
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    let predictfruit = PredictFruit()

    @IBOutlet weak var imgFruit: UIImageView!
    @IBOutlet weak var classificationLabel: UILabel!
    @IBAction func capturePhoto(_ sender: Any) {
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            var imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true) {
            guard let photo = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else {
                print("No image found")
                return
            }
            
            self.imgFruit.image = photo
            // Get the prediction back from predictImage()
            if let prediction = self.predictfruit.predictImage(imageToClassify: photo) {
                self.classificationLabel.text = prediction.rawValue
            } else {
                self.classificationLabel.text = "Error"
            }
        }
    }

}

