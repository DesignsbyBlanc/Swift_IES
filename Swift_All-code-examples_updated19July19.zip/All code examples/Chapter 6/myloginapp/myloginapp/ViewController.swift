//
//  ViewController.swift
//  myloginapp
//
//
//  
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var TxtUsername: UITextField!
    @IBOutlet weak var TxtPassword: UITextField!
    @IBAction func LoginTouch(_ sender: Any) {
        Auth.auth().signIn(withEmail: TxtUsername.text!, password: TxtPassword.text!) { (user, error) in
            if error != nil {
                let alertController = UIAlertController(title: "Login Error",
                message: "Login error. Please try again.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            } else {
                print("Success")
                self.performSegue(withIdentifier: "goProfile", sender: self)
            }
        }
    }
    
    @IBAction func RegisterTouch(_ sender: Any) {
        Auth.auth().createUser(withEmail: TxtUsername.text!, password: TxtPassword.text!) { (user, error) in
            if error != nil {
                let alertController = UIAlertController(title: "Account Error",
                    message: "There was a problem creating your account. Please try again.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            } else {
                let alertController = UIAlertController(title: "Account Created",
                    message: "Your account has been created. Please login.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

