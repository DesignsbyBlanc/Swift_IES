//
//  ProfileViewController.swift
//  myloginapp
//
//
//
//

import UIKit
import Firebase

class ProfileViewController: UIViewController,
UIImagePickerControllerDelegate,
UINavigationControllerDelegate  {

    @IBOutlet weak var TxtName: UITextField!
    @IBOutlet weak var TxtCity: UITextField!
    @IBOutlet weak var TxtWeb: UITextField!
    @IBOutlet weak var TxtBio: UITextView!
    @IBOutlet weak var ProfileImage: UIImageView!
    
    
    @IBAction func SaveTouch(_ sender: Any) {
        
        //Check to see if the text boxes are empty
        if TxtName.text == "" || TxtCity.text == "" ||
            TxtWeb.text == "" || TxtBio.text == "" {
            alertType(title: "Entry error", message: "Please enter values in all text boxes.")
        }
        else {
            //Database and UID references
            var ref: DatabaseReference!
            ref = Database.database().reference()
            let useruid = Auth.auth().currentUser?.uid
            
            //Update database with textbox values
            ref.child("users/" + useruid! + "/name").setValue(TxtName.text)
            ref.child("users/" + useruid! + "/city").setValue(TxtCity.text)
            ref.child("users/" + useruid! + "/web").setValue(TxtWeb.text)
            ref.child("users/" + useruid! + "/bio").setValue(TxtBio.text)
            alertType(title: "Profile Updated", message: "Your profile has been updated.")
            
        }
    }
    
    @IBAction func UpdatePhoto(_ sender: Any) {
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        ProfileImage.image = image
        dismiss(animated: true, completion: nil)
        imageUpload()
    }
    
    
    @IBAction func LogoutTouch(_ sender: Any) {
        
        do {
            try Auth.auth().signOut()
            //Send the user back to the loginscreen
            self.performSegue(withIdentifier: "goLogin", sender: self)
        }
        catch {
            alertType(title: "Logout Error",
            message: "Please try again.")
        }
    }
    
    func alertType(title: String, message: String) {
        let alertController = UIAlertController(title: title,
        message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func imageUpload () {
        let useruid = Auth.auth().currentUser?.uid
        
        let imageData = ProfileImage.image!.jpegData(compressionQuality: 0.4)
        let storageRef = Storage.storage().reference().child("images/" + useruid! + ".jpg")
        if let uploadData = imageData {
            storageRef.putData(uploadData, metadata: nil) { (metadata, error) in
                if error != nil {
                    self.alertType(title: "Profile Photo", message: "There was an error uploading your photo.")
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var ref: DatabaseReference!
        ref = Database.database().reference()
        
        let useruid = Auth.auth().currentUser?.uid
        ref.child("users").child(useruid!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user values
            let value = snapshot.value as? NSDictionary
            self.TxtName.text = value?["name"] as? String ?? ""
            self.TxtCity.text = value?["city"] as? String ?? ""
            self.TxtWeb.text = value?["web"] as? String ?? ""
            self.TxtBio.text = value?["bio"] as? String ?? ""
            
            // Create reference to profile image
            let imgRef = Storage.storage().reference().child("images/" + useruid! + ".jpg")
            
            // Download image in memory
            imgRef.getData(maxSize: 1 * 1024 * 1024) { data, error in
                if let error = error {
                } else {
                    let image = UIImage(data: data!)
                    self.ProfileImage.image = image
                }
            }
        }) { (error) in
            print(error.localizedDescription)
        }
        
    }

}
