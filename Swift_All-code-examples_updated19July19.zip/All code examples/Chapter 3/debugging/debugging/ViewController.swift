//
//  ViewController.swift
//  debugging
//
//
//  
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Setup original values
        var int1 = 14
        var int2 = 56
        //Changing int1
        int1 = int1 + 12
        print(int1)
        //Call method
        testmethod(myint: int2)
    }
    
    func testmethod (myint: Int)
    {
        print("You have successfully reached this method")
        print (myint)
    }

}

