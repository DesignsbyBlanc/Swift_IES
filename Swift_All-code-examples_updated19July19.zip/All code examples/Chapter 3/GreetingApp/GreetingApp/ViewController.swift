//
//  ViewController.swift
//  GreetingApp
//
//
//  
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LblMessage: UILabel!
    @IBOutlet weak var TxtName: UITextField!
    @IBOutlet weak var switchDate: UISwitch!
   
    @IBAction func pushButton(_ sender: Any) {
        let userName: String = TxtName.text ?? "Unknown"
        
        //Get current date, and get it in medium date format (no time)
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = DateFormatter.Style.none
        dateFormatter.dateStyle = DateFormatter.Style.medium
        let datestring = dateFormatter.string(from: date)
        
        //If switch is on then print greeting and date, if not print greeting only
        if switchDate.isOn {
            LblMessage.text = "Hello " + userName + ". Today's date is \(datestring)."
        }
        else {
            LblMessage.text = "Hello " + userName
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

