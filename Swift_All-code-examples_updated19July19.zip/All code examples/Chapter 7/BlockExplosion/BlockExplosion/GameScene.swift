//
//  GameScene.swift
//  BlockExplosion
//
//
//  
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var gameModel = BlockModel()
    var selectedTile : BlockTile?
    var scoreLabel : SKLabelNode!
    
    var gameScore: Int = 0 {
        didSet {
            scoreLabel.text = "Score: " + String(gameScore)
        }
    }
    
    override func didMove(to view: SKView) {
        self.setup()
        
    }
    
    func setup () {
        self.backgroundColor = UIColor.purple
        self.gameModel.myGameScene = self
        self.gameModel.setupModel()
        self.gameModel.populateModel()
        self.arrangeTiles()
        self.createScoreboard()
    }
    
    func createScoreboard() {
        scoreLabel = SKLabelNode(fontNamed: "ArialMT")
        scoreLabel.horizontalAlignmentMode = .center
        scoreLabel.fontSize = 40
        scoreLabel.zPosition = 99
        scoreLabel.position = CGPoint(x: 0,y: -(self.frame.size.height / 2) + 80)
        scoreLabel.text = "Score: " + String(gameScore)
        addChild(scoreLabel)
    }
    
    func setupSprite(_ withImage:Int) -> BlockTile {
        
        let sprite = BlockTile(imageNamed:"tile_"+String(withImage))
        
        sprite.tileType = withImage
        sprite.xScale = 1.5
        sprite.yScale = 1.5
        
        self.addChild(sprite)
        
        return sprite
    }
    
    func arrangeTiles() {
        
        let gridInfo = self.gridInformation()
        
        var location = CGPoint(x: gridInfo.margin + (gridInfo.tileSize / 2), y: gridInfo.startY)
        var i = 0
        
        for verticalStrip in self.gameModel.TwoDArray {
            
            var verticalCounter = 1
            
            //Loop though each tile in the strip
            for gameTile in verticalStrip {
                
                let convertedLocation = self.convertPoint(fromView: location)
                
                gameTile.run(SKAction.move(to: convertedLocation, duration: 0.1 * Double(verticalCounter)))
                location.y -= gridInfo.tileSize
                
                gameTile.outerIndex = i
                
                verticalCounter += 1
            }
            
            location.x += gridInfo.tileSize
            location.y = gridInfo.startY
            i += 1
        }
        
    }

    
    
    func touchDown(atPoint pos : CGPoint) {
 
    }
    
    func touchMoved(toPoint pos : CGPoint) {

    }
    
    func touchUp(atPoint pos : CGPoint) {

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let clickLocation = touches.first?.location(in: self.view)
        let convertedLocation = self.convertPoint(fromView: clickLocation!)
        
        let clickedNode = self.atPoint(convertedLocation)
        
        if (clickedNode.isKind(of: BlockTile.self) == false) {
            print("you didn't click a tile!")
            return
        } else {
            print("Tile!" + clickedNode.debugDescription)
        }
       let pressedTile =  clickedNode as! BlockTile
       self.tileWasPressed(pressedTile)
 
    }
    
    func tileWasPressed(_ pressedTile: BlockTile) {
        
        pressedTile.playSelect()
        
        var spinForever = true
        // Decide whether to spin forever or not - dependent on tile selection
        if (self.selectedTile == nil) {
            self.selectedTile = pressedTile
            spinForever = true
        } else {
            spinForever = false
        }
        
        //Create rotation action
        let action = SKAction.rotate(byAngle: 3, duration: 1)
        
        if (spinForever) {
            // Repeat spin action forever
            pressedTile.run(SKAction.repeatForever(action))
        } else {
    
            pressedTile.run(action,completion: {
                
                self.selectedTile!.removeAllActions()
                self.gameModel.switchTiles(pressedTile,otherPiece: self.selectedTile!)
                self.selectedTile = nil
                self.findMatchesAndRepopulate()
                
            })
            
        }
    }
    
    func findMatchesAndRepopulate() {
        
        self.arrangeTiles()
        
        let tilesToRemove = self.gameModel.findMatches()
        
        self.gameModel.removeTiles(tilesToRemove)
        
        if (tilesToRemove.count == 0) {
            if gameScore >= 150 {
                let secondScene = BlockScene2(fileNamed: "BlockScene2")
                let transition = SKTransition.flipVertical(withDuration: 1.0)
                secondScene?.scaleMode = .aspectFill
                scene?.view?.presentScene(secondScene!, transition: transition)
            }
            else {
                return
            }
        }
        
        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { (_) in
            self.gameModel.populateModel()
            self.arrangeTiles()
            self.findMatchesAndRepopulate()
        }
    }

    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
    }
    
    func gridInformation() -> (margin: CGFloat, tileSize: CGFloat, startY: CGFloat) {
        
        let gridMargin = CGFloat(20)
        let tileSize = (UIScreen.main.bounds.size.width - CGFloat(gridMargin * 2)) / 10
        
        let startY = (tileSize * 10) + gridMargin
        
        return (margin:gridMargin,tileSize:tileSize,startY:startY)
    }
}
