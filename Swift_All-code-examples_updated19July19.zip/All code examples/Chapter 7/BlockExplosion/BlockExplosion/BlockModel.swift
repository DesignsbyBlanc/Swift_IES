//
//  BlockModel.swift
//  BlockExplosion
//
//
//  
//

import UIKit

class BlockModel: Any {
    var TwoDArray = [[BlockTile]]()
    
    var matchLengthRequired = 3
    
    weak var myGameScene : GameScene!
    
    func setupModel() {
        var i = 0
        while (i < 10) {
            let newArray  = [BlockTile]()
            self.TwoDArray.append(newArray)
            i += 1
        }
    }
    
    func populateModel() {
        var i = 0
        while (i < 10) {
            while (self.TwoDArray[i].count < 10) {
                let dice = BlockUtils.randomNumberBetweenOneAndSix()
                let BlockTile =  self.myGameScene.setupSprite(dice)
                BlockTile.outerIndex = i
                self.TwoDArray[i].append(BlockTile)
            }
            i += 1
        }
    }
    
    func findMatches() -> [BlockTile] {
        
        var matches = [BlockTile]()
        
        let verticalMatches = self.findMatches(inStrips: self.TwoDArray)
        matches.append(contentsOf: verticalMatches)
        
        let horizontalMatches = self.findMatches(inStrips: self.rotatedGrid())
        matches.append(contentsOf: horizontalMatches)
        
        return matches
        
    }
    
    func removeTiles(_ tilesToRemove:[BlockTile]) {
        for tile in tilesToRemove {
            self.deleteTile(tile)
        }
    }
    
    func deleteTile(_ tile:BlockTile) {
        var  i = 0
        
        myGameScene.gameScore += 1
        
        tile.playMatch()
        
        while (i < self.TwoDArray.count) {
            let verticalstrip = self.TwoDArray[i]
            if (verticalstrip.firstIndex(of: tile) != nil) {
                self.TwoDArray[i].remove(at: verticalstrip.firstIndex(of: tile)!)
            }
            i += 1
            
        }
        
    }
    
    func rotatedGrid() ->  [[BlockTile]] {
        let length = self.TwoDArray[0].count
        var returnValue = [[BlockTile]](repeating: [BlockTile](), count: length)
        for index in 0..<length {
            returnValue[index] = self.TwoDArray.map{ $0[index] }.reversed()
        }
        return returnValue
    }
    
    func switchTiles(_ firstPiece: BlockTile, otherPiece: BlockTile) {
        
        let firstPieceOuterIndex = firstPiece.outerIndex
        let otherPieceOuterIndex = otherPiece.outerIndex
        
        let firstPieceInnerIndex =  self.TwoDArray[firstPieceOuterIndex].firstIndex(of: firstPiece)
        let otherPieceInnerIndex =  self.TwoDArray[otherPieceOuterIndex].firstIndex(of: otherPiece)
        
        //Switch the position of the two tiles
        self.TwoDArray[firstPieceOuterIndex].remove(at: firstPieceInnerIndex!)
        self.TwoDArray[firstPieceOuterIndex].insert(otherPiece, at: firstPieceInnerIndex!)
        self.TwoDArray[otherPieceOuterIndex].remove(at: otherPieceInnerIndex!)
        self.TwoDArray[otherPieceOuterIndex].insert(firstPiece, at: otherPieceInnerIndex!)
        
        firstPiece.outerIndex = otherPieceOuterIndex
        otherPiece.outerIndex = firstPieceOuterIndex
        
    }
    
    func findMatches(inStrips:[[BlockTile]]) -> [BlockTile] {
        
        var foundPieces = [BlockTile]()
        
        for strip in inStrips {
            
            var currentType = strip[0].tileType
            var i = 1
            
            var stack = [BlockTile]()
            
            stack.append(strip[0])
            
            while (i < strip.count) {
                let cp = strip[i]
                
                if (cp.tileType == currentType) {
                    stack.append(cp)
                } else {
                    if (stack.count >= self.matchLengthRequired) {
                        foundPieces.append(contentsOf: stack)
                    }
                    stack.removeAll()
                    currentType = strip[i].tileType
                    
                    stack.append(strip[i])
                }
                
                i += 1
            }
            //Check to see if the stack is greater or equal to match length
            if (stack.count >= self.matchLengthRequired) {
                foundPieces.append(contentsOf: stack)
                stack.removeAll()
            }
            
        }
        
        return foundPieces
    }

}
