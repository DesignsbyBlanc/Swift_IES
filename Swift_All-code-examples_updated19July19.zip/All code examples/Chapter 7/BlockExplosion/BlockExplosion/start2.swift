//
//  start2.swift
//  BlockExplosion
//
//  Created by Darryl Bartlett on 19/01/2019.
//  Copyright © 2019 Darryl Bartlett. All rights reserved.
//

import SpriteKit

class start2: SKScene {
    
    
    override func didMove(to view: SKView) {
        self.backgroundColor = UIColor.red
        
    }
}
