//
//  BlockUtils.swift
//  BlockExplosion
//
//
//  
//

import UIKit

class BlockUtils: Any {
    class func randomNumberBetweenOneAndSix() -> Int {
        return Int(arc4random_uniform(UInt32(5))) + 1
    }
}
