//
//  BlockScene2.swift
//  BlockExplosion
//
//
//  
//

import UIKit
import SpriteKit

class BlockScene2: SKScene {

    override func didMove(to view: SKView) {
        var thanksLabel : SKLabelNode!
        self.backgroundColor = SKColor(red: 0.15, green: 0.15, blue: 0.3, alpha: 1.0)
        thanksLabel = SKLabelNode(fontNamed: "ArialMT")
        thanksLabel.horizontalAlignmentMode = .center
        thanksLabel.fontSize = 50
        thanksLabel.zPosition = 99
        thanksLabel.position = CGPoint(x: 0,y: -(self.frame.size.height / 2) + 80)
        thanksLabel.text = "Thank you for playing!"
        addChild(thanksLabel)
    }
    
}
