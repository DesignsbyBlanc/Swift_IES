//
//  BlockScoreboard.swift
//  BlockExplosion
//
//  Created by Darryl Bartlett on 19/01/2019.
//  Copyright © 2019 Darryl Bartlett. All rights reserved.
//

import UIKit
import SpriteKit

class BlockScoreboard: SKSpriteNode {

    var scoreLabel : SKLabelNode!
    
    func setup () {
        scoreLabel = SKLabelNode(fontNamed: "ArialMT")
        scoreLabel.horizontalAlignmentMode = .center
        scoreLabel.fontSize = 40
        scoreLabel.zPosition = 99
        scoreLabel.position = CGPoint(x: 0,y: -(self.frame.size.height / 2) + 80)
        scoreLabel.text = "0"
        addChild(scoreLabel)
    }
    
}
