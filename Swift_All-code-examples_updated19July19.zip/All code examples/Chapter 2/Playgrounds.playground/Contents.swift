import UIKit

var str = "Hello, playground"

var greeting = "Hello Swift"
print(greeting)

greeting = "Hello John"

var firstName = "John"
firstName = "James"

var message: String = "Hello"
var myNo: Int = 100
var floatval: Float = 3.14
var doubleval: Double = 345.344544
var isSuccess: Bool = true
let playerInfo = ("Mark", 20)

var message1: String = "Hello there"
var message2: String = "Swift fans"
message1 + " " + message2

var num1: Int = 12
var num2: Int = 30
num1 + num2

var first: Int = 13
var second: Int = 6
first % second

4 == 4        //True: 4 is equal to 4
3 != 2         //True: 3 is not equal to 2
4 > 5        //False: 4 is not greater than 5
6 < 8        //True: 6 is less than 8
2 >= 2        //True: 2 is equal to 2
5 <= 4        //False: 5 is not less than or equal to 4

var number1 = 8
var number2 = 10
//This will return false
number1 == number2

let strNo = "215"
let myInt1 = Int(strNo)
print(myInt1!)

var myTestNumber: Int = 12
if myTestNumber < 100 {
    print("The number is lower than 100")
}

var myHighNumber: Int = 102
if myHighNumber < 100 {
    print("The number is lower than 100")
}
else {
    print("The number is higher than 100")
}

let myNumber = 9
if (myNumber < 0) {
    print("The number is negative")
} else if myNumber < 10 {
    print("The number is single digit")
} else {
    print("The number is multi-digit")
}

var index = 10

switch index {
case 5:
    print("Value of index is 5")
case 10, 15:
    print("Value of index is 10 or 15")
case 100:
    print("Value of index is 100")
default:
    print("Default case")
}

var fruitList = ["apple", "banana", "orange", "pear"]
print (fruitList[1])

fruitList[0] = "watermelon"

var countries = ["GBR": "Great Britain", "USA": "United States"]
countries["GBR"]

let employees = ["John", "Doe", "Smith"]
for emp in employees {
    print(emp)
}

let employeeDictionary = ["John": 1001, "Smith": 1002, "Doe": 1003]
for (empName, empID) in employeeDictionary {
    print("Employee ID: \(empID), Employee Name: \(empName) ")
}

for index in 1...5 {
    print(index)
}

for index in 1..<5 {
    print(index)
}

var i = 1
while i < 5 {
    print(i)
    i = i + 1
}

var myString: String?
if let string = myString {
    print(string)
}

var myNewString: String?
print(myNewString ?? "Hello")

//The function itself
func hello() {
    print("You called me!")
}

//Calling a function
hello()

//The function expecting an integer
func helloNew(age: Int) {
    print("You said your age was", age)
}

//Calling a function with integer
helloNew(age: 20)

var myage = 30
//Function takes age and adds 10
func ageWorkout(age: Int) -> Int {
    return age + 10
}
print(ageWorkout(age: myage))








